module.exports = function EmailException() {
  this.message = 'email_failure';
  this.status = 502;
};
