# JavaScript TDD Project

Example repo for [JavaScript Test-Driven Development with Jest](https://youtu.be/Jv2uxzhPFl4). 

Challenge: Implement additional tests in the `test/stack.test.js` file. 